<template>
  <div>
  <cheader></cheader>
  <circleBanner></circleBanner>
  <circleHot></circleHot>
  <circleGroup></circleGroup>
  </div>
</template>
<script>
  import circleBanner from '../components/circle/circle-banner'
  import circleHot from '../components/circle/circle-hot'
  import circleGroup from '../components/circle/circle-group'
  import cheader from '../components/header'
  export default {
    components: {
      cheader,
      circleBanner,
      circleHot,
      circleGroup
    },
    data () {
      return {
        loading:false,
      }
    }
  }
</script>
