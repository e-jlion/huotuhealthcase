/**
 * Created by Administrator on 2016/10/11.
 */
/**
 * 更新loading
 * @param  {Function} options.dispatch store对象解构出来的函数，无需手动提供
 */
export const updateLoading = ({ commit, state }, loading)=>{
  commit("UPDATE_LOADING", {
    loading:loading
  })
};
