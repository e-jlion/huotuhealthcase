<!--suppress ALL -->
<template>
  <div id="app">
    <div class="main">
      <router-view></router-view>
      <div style="height: 60px"></div>
    </div>
    <cfooter></cfooter>
  </div>
</template>
<script>
  import cfooter from './components/footer'
  import loading from './components/loading'
  import store from './vuex/store';
  export default {
    components: {
      cfooter
    },
    store
  }
</script>
<style>
  @import "../static/css/weui.min-gggeren-diy.css";
</style>
