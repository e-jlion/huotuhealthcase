<template>
  <div>
    <div class="weui_navbar daohangs">
      <a href="javascript:void(0);" class="weui_navbar_item weui_bar_item_on">
        <p class="kimg dhshouyeicon"></p>
        <p>首页</p>
      </a>
      <a href="javascript:void(0);" class="weui_navbar_item ">
        <p class="kimg dhfenleiicon"></p>
        <p>分类</p>
      </a>
      <a href="javascript:void(0);" class="weui_navbar_item">
        <p class="kimg faxxx"></p>
        <p style="z-index:99999; position:absolute;left:0px;right:0px;">发现</p>
        <div style="position:absolute;bottom:0px;left:0px;right:0px;">
          <p class="faxxxicon"></p>
          <div style="position:absolute;bottom:0px;left:0px;right:0px; z-index:-1">
            <p style=" height:5.5em; text-align:center; margin:0 auto;background-color:#fff; border-radius:100%; border:1px solid #eee">
            </p> </div>
        </div>
      </a>
      <a href="javascript:void(0);" class="weui_navbar_item">
        <p class="kimg dhgouwucheicon"></p>
        <p>购物车</p>
      </a>
      <a href="javascript:void(0);" class="weui_navbar_item weui_bar_item_on">
        <p class="kimg dhzhongxinicon"></p>
        <p> 我的</p>
      </a>
    </div>

    <div class="fonthui" style="position:relative">
      <div class="grs">
        <a href="javascript:void(0);" class="z"><img src="/static/images/ddicon/zzdxx.png"  style="width:100%"></a>
        <a href="javascript:void(0);" class="y"><img src="/static/images/ddicon/sszz.png" style="width:100%"></a>
      </div>
      <div class="grsbg" style="background-image: url(/static/images/bolang.jpg); background-repeat:no-repeat; background-size:100% 100%; background-position:top center">
        <div class="grsjz">
          <div class="grstx">
            <img src="/static/images/mrtx.jpg">
          </div>
        </div>
        <div class="grsname">
          <p style="color:#111; font-size:16px"><b>小猫猫</b></p>
          <p>写句签名吧，让大家更了解你~</p>
        </div>
        <div class="weui_navbar dfd" style="z-index:12; position: static">
          <a class="weui_navbar_item"> 99999+ 发帖 </a>
          <a class="weui_navbar_item"> 5 关注 </a>
          <a class="weui_navbar_item"> 52213 粉丝 </a>
        </div>
      </div>
    </div>
    <!--end-->
    <div class="gerendiy">
      <div class="weui_cells weui_cells_access">
        <a class="weui_cell" href="javascript:void(0);">
          <div class="weui_cell_bd weui_cell_primary">
            <p>我的钱包</p>
          </div>
          <div class="weui_cell_ft" style="font-size:12px">
            充值、提现
          </div>
        </a>
      </div>
      <div class="dailiren-s-ka duu">
        <ul class="dailiren-float-ul ka  pjf_4ge ">
          <li>
            <a href="javascript:void(0);">
              <p class="sj">3531<span style="font-size:0.5em">.93</span></p>
              <p>账户余额</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p class="sj">6530</p>
              <p>可用积分</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p class="sj">875</p>
              <p>待定积分</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p class="sj">3411<span style="font-size:0.5em">.00</span></p>
              <p>小金库</p>
            </a>
          </li>
        </ul>
      </div>
      <div class="weui_cells weui_cells_access">
        <a class="weui_cell" href="javascript:void(0);">
          <div class="weui_cell_bd weui_cell_primary">
            <p>我的订单</p>
          </div>
          <div class="weui_cell_ft" style="font-size:12px">
            查看全部订单
          </div>
        </a>
      </div>
      <div class="dailiren-s-ka duu">
        <ul class="dailiren-float-ul ka  pjf_4ge ">
          <li>
            <a href="javascript:void(0);">
              <p>
                <img src="/static/images/ddicon/g4.png" class="ccgg">
              </p>
              <p class="number b">50</p>
              <p>待付款</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p><img src="/static/images/ddicon/g3.png" class="ccgg">
              </p>
              <p class="number">0</p>
              <p>待收货</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p ><img src="/static/images/ddicon/g2.png" class="ccgg"></p>
              <p class="number ">0</p>
              <p>已收货</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p ><img src="/static/images/ddicon/g1.png" class="ccgg"></p>
              <p class="number b">5</p>
              <p>售后</p>
            </a>
          </li>
        </ul>
      </div>
      <div class="weui_cells weui_cells_access">
        <div class="weui_cell">
          <div class="weui_cell_bd weui_cell_primary">
            <p>常用功能</p>
          </div>
        </div>
      </div>
      <div class="dailiren-s-ka line">
        <ul class="dailiren-float-ul ka  pjf_4ge ">
          <li>
            <a href="javascript:void(0);">
              <p>
                <img src="/static/images/ddicon/shouc.png" class="ccgg">
              </p>
              <p class="number zs"></p>
              <p>我的收藏</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p><img src="/static/images/ddicon/g.3.png" class="ccgg">
              </p>
              <p class="number zs"></p>
              <p>优惠券</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p ><img src="/static/images/ddicon/g.5.png" class="ccgg"></p>
              <p class="number zs b">11</p>
              <p>最新消息</p>
            </a>
          </li>
          <li>
            <a href="javascript:void(0);">
              <p ><img src="/static/images/ddicon/x6.png" class="ccgg"></p>
              <p class="number zs"></p>
              <p>积分</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <!--end-->
    <cloading v-show='loading'></cloading>
  </div>
</template>
<script>
  import { getLoading } from '../../vuex/getters'
  import cloading from '../../components/loading'
  import { updateLoading } from '../../vuex/actions'
  export default {
    data () {
      return {
        test:false,
      }
    },
    vuex: {
      getters: {
        loading: getLoading,
      },
      actions: {
        updateLoading,
      }
    },
    components: {
      cloading
    },
    created () {
//      this.updateLoading(false)
    }
  }
</script>
