import Vue from 'vue'
import App from './App'
import VueRouter from 'vue-router'
import circle from './views/circle'
import attention from './views/attention'
import science from './views/science'
import adminIndex from './views/admin/index'

Vue.use(VueRouter)

const routes = [
  {path: '/', name: 'circle', component: circle},
  {path: '/index', name: 'circle', component: circle},
  {path: '/attention', nane: 'attention', component: attention},
  {path: '/science', nane: 'science', component: science},
  {path: '/admin/index', nane: 'adminIndex', component: adminIndex},
  {path: '*', nane: 'circle', component: circle}
]
const router = new VueRouter({
  routes:routes
})

router.beforeEach((to, from, next) => {
  next();
})
new Vue({
  render: h => h(App),
  router
}).$mount('#app')
