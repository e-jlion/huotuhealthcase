<template>
  <div>
  <cheader></cheader>
  <div class="weui_tab_bd" style="padding-bottom:0px">
    <div class="cont-zhbox">
      <div class="cont-zhbox-t">
        <a href="geren-index8.html" class="bz" >
          <p class="cont-zhbox-a"><b>韩媒:朝鲜遭遇严重干旱粮食缺口近70万吨粮食缺口近70万吨</b></p>
          <p class="cont-zhbox-img"><img src="/static/images/j2.jpg"></p>
          <p class="cont-zhbox-nav"></p>
        </a>
        <div class="zhbox">
          <div class="zh-tx">
            <img src="/static/images/imgsss.png">
          </div>
          <div class="zh-wz">
            <div class="zh-wz-x">
              <p class="zh-wz-name"> 官方发布<img src="/static/images/ddbm.png" class="zh-wz-name-ico"></p>
            </div>
            <div class="njk">
              <a href="javascript:;" class="weui_btn weui_btn_mini weui_btn_default">关注</a>
            </div>
            <div  class="zh-wz-time">
              <span style="float:left">23小时前</span>
              <span style="float:right"></span>
              <span style="float:right; margin-right:10px"></span>
              <p style="clear:both"></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cont-zhbox">
      <div class="cont-zhbox-t">
        <a href="geren-index8.html" class="bz" >
          <p class="cont-zhbox-a"><b>韩媒:朝鲜遭遇严重干旱粮食缺口近70万吨粮食缺口近70万吨</b></p>
          <p class="cont-zhbox-img"></p>
          <p class="cont-zhbox-nav">瑞银在周二发布的一份报告中研究了部分国家的房地产市场，发现2011年来，有泡沫风险的地区房价上涨了几乎50%。瑞银认为，温哥华的房价在2008年的金融危机中没有受到影响，大宗商品走弱的背景下反而还在持续上涨。</p>
        </a>
        <div class="zhbox">
          <div class="zh-tx">
            <img src="/static/images/imgsss.png">
          </div>
          <div class="zh-wz">
            <div class="zh-wz-x">
              <p class="zh-wz-name"> 官方发布<img src="/static/images/ddbm.png" class="zh-wz-name-ico"></p>
            </div>
            <div class="njk" style="display:none">
              <a href="javascript:;" class="weui_btn weui_btn_mini weui_btn_default">关注</a>
            </div>
            <div  class="zh-wz-time">
              <span style="float:left">09-10 22:00</span>
              <span style="float:right">回复32</span>
              <span style="float:right; margin-right:10px">浏览38281</span>
              <p style="clear:both"></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</template>
<script>
  import cheader from '../components/header'
  export default {
    components: {
      cheader
    },
    data () {
      return {
        loading:false,
      }
    },
  }
</script>
