<template>
  <div class="swiper-container"  data-space-between='10' data-pagination='.swiper-pagination' data-autoplay="1000">
    <div class="swiper-wrapper" style="line-height:0px">
      <div class="swiper-slide"><a href="geren-index8.html"><img src="/static/images/rrr.jpg" style="width:100%" alt=""></a></div>
      <div class="swiper-slide"><a href="geren-index8.html"><img src="/static/images/rrr.jpg" style="width:100%" alt=""></a></div>
      <div class="swiper-slide"><a href="geren-index8.html"><img src="/static/images/rrr.jpg" style="width:100%" alt=""></a></div>
    </div>
    <div class="swiper-pagination" style="bottom:4px;" ></div>
  </div>
</template>
<script>
 import Swiper from 'swiper'
 export default {
   data () {
     return {}
   },
   created () {
     this.$nextTick(() => {
       let mySwiper = new Swiper('.swiper-container', {
         loop: true,
         autoplay: 3000
       })
     })
   },
 }
</script>
<style>
  @import 'http://resali.huobanplus.com/cdn/swiper/3.3.1/css/swiper.min.css';
</style>
