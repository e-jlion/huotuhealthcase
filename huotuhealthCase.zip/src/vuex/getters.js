/**
 * Created by Administrator on 2016/10/10.
 */
export function getLoading (state) {
  return true;
  // return state.loading;
}
